// 네비게이터 js (수정 필요)

$(function(){
    $(".nav-list").hover(function(e){
        e.stopPropagation();
        $(".nav-list").find("ul").slideToggle(200);
    });

    $(window).scroll(function(){
        var height = $(document).scrollTop();
        if($(document).scrollTop() > $("header").height()) {
            $("nav").addClass("nav-fix");
            $("#nav-logo").css("display", "flex");
        }
        else {
            $("nav").removeClass("nav-fix");
            $("#nav-logo").css("display", "none");
        }
    });
});